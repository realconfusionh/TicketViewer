#import datetime
import csv
import pandas as pd
import sys
import os
from PyQt5 import QtCore
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel # GUI
class TicketViewer:
    def __init__(self, menu, customerdetails,option ):
        self.menu = menu
        self.customerdetails = customerdetails
        self.option = option
def menu():
        print(" Hello & Welcome \n Customer Section \n Press the Options to choose : ")
        print(" 1 To book a ticket : \n 2 View all the tickets  : \n 3 if more than 25 tk than stop : \n 4 To display specific ticket. ")
menu() 
def customerdetails(): 
    option = int(input())
    while True:
        if option == 1:
            print("Enter your Details : " )
            print("Enter you Last and First name : ")
            name = str(input())
            print("Now Enter your DOB format 01/01/0000 :")
            DOB = str(input())
            print("Enter your email address : ")
            email = input()
            print("Enter your Destination : ")
            Destination = input()
            print("Passanger name : {0} Date of Birth : {1} Email : {2} Destination : {3} " .format(name,DOB,email,Destination))
            myData = [name,DOB,email,Destination]
            myFile = open('names.csv', 'a' ,newline='')
            with myFile:
                writer = csv.writer(myFile,delimiter = ',')
                writer.writerows([myData])
            break
        elif option == 2:
            df = pd.read_csv('names.csv')
            print(df)
            break 
        elif option == 3:
            rows = [] 
            with open('names.csv', 'r') as csvfile: 
                csvreader = csv.reader(csvfile)  
                for row in csvreader: 
                    rows.append(row) 
                print(" when It reached to 25 it will break.Total no. of rows : %d"%(csvreader.line_num)) 
                #print(row)
                if csvreader.line_num > 25:
                    print(row)
                    break           
        elif option == 4:
            #ticketnumber = input()
            df = pd.read_csv('names.csv')
            #if df.where == ticketnumber:
            print(df.iloc[1:2])
            #print(df)
        break
                     
customerdetails()
class UserInterface(QWidget):
    def __init__(self):
        super().__init__()
        self.qMidLabel = QLabel('Hello and Welcome ', self)
        self.qMidLabel.move(40, 20)
        
        self.qbtn = QPushButton('book a Ticket', self)
        self.qbtn.resize(self.qbtn.sizeHint())
        self.qbtn.move(80, 50)  # xpos, ypos 

        self.qbtn1 = QPushButton('All Ticket', self)
        self.qbtn1.resize(self.qbtn.sizeHint())
        self.qbtn1.move(80, 80)  # xpos, ypos 

        self.qbtn2 = QPushButton('your Ticket', self)
        self.qbtn2.resize(self.qbtn.sizeHint())
        self.qbtn2.move(80, 110)  # xpos, ypos 
        
        
def onQApplicationStarted(self):
        print('started')           
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ui = UserInterface()
    ui.show()
    t = QtCore.QTimer()
    sys.exit(app.exec_())